

## Spotify Playlist Manager Project
### Goals
- Provide a better interface for viewing and editing playlists
- Show the user's top tracks
- Allow the user to search for tracks to add to their playlists.
	
