package com.example.spotifyplaylistmanager.data;

import java.io.Serializable;

public class ArtistImage implements Serializable {
    public int height;
    public String url;
    public int width;
}
