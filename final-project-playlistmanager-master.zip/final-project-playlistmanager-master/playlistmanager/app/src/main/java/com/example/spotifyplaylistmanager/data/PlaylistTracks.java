package com.example.spotifyplaylistmanager.data;

import java.io.Serializable;

public class PlaylistTracks implements Serializable {
        public String href;
        String total;
}
