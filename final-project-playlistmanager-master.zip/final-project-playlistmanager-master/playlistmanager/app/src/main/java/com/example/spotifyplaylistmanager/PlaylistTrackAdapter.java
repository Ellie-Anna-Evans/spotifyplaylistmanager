package com.example.spotifyplaylistmanager;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

//public class PlaylistTrackAdapter extends RecyclerView.Adapter {
//
//    private ArrayList<String> mTracksList;
//
//    public PlaylistTrackAdapter() {
//        mTracksList = new ArrayList<String>();
//    }
//
//    public void addTrack(String track){
//        mTracksList.add(track);
//    }
//
//}
